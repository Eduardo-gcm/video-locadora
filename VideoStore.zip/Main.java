/**
* Engenharia de Software Moderna 
* Prof. Marco Tulio Valente
* 
* Roteiro Prático sobre refactoring
* 
* Classes iniciais do sistema de videolocadora
*
*/

class Main {
  public static void main(String[] args) {
    System.out.println("Apenas um exemplo de refatoração...");
  }
}